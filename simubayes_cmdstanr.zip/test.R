# ### Install simubayes
# install.packages("cmdstanr", repos = c('https://stan-dev.r-universe.dev', getOption("repos")))
# library(cmdstanr)
# check_cmdstan_toolchain()
# check_cmdstan_toolchain(fix = TRUE)
# install_cmdstan(cores = 2)
# cmdstan_path()
# cmdstan_version()
# 
# #install.packages("instantiate")
# #library(instantiate)
# #stan_package_create(path = "package_folder")
# #stan_package_configure(path = "package_folder")
# 
# 
# ## Re-Compile
# #detach("package:simubayes2", unload=TRUE)
library(roxygen2)
roxygenise("package_folder")

## Install Package
install.packages(pkgs = "package_folder", type = "source", repos = NULL)


## ---------------------------------------------------------------------
##
##    EXAMPLE : Start Shiny App
##
## ---------------------------------------------------------------------

library("simubayes2")
stb_shiny()

## ---------------------------------------------------------------------
##
##    EXAMPLE : Bayesian Multi-Stage Design for Binary Endpoint
##
## ---------------------------------------------------------------------

## Binary Endpoint

### Borrow log odds ratio
### Simulated R7508 ROXI-II Study
### test H0: logOR = 0 vs H1: logOR < 0

h_prior = stb_tl_bayes_para_rmap(dtype = 'binary',
                                 borrow = 'logOR',
                                 logOR = -0.6,
                                 logOR.se = 0.35,
                                 v = 1,
                                 m = 0,
                                 s = 1,
                                 weight_noninfo = 0.5,
                                 prior1_noninfo = 0,
                                 prior2_noninfo = 1,
                                 cores = 1)

prior = stb_tl_bayes_para_pp(logOR = c(-0.6, -0.5),
                             logOR.se = c(0.35, 0.35),
                             dtype = 'binary',
                             borrow = 'logOR',
                             prior1 = 0,
                             prior2 = 0.843,
                             power.param = 0.5,
                             stan_mdl = "n_pp",
                             cores = 1)

xx = stb_create_design("bayes_mstage_bin")
stb_describe(xx)
stb_get_para(xx)

### check type 1 error

stb_para(xx)=list(sample_size     = 100,
                  ratio_by_arm    = c(1, 2),
                  ratio_by_stage  = 1,
                  p_by_arm        = c(0.224, 0.224),
                  prior_by_arm    = list(prior),
                  n_post          = 10000,
                  test_direction  = 'less than',
                  decision_h0     = 0,
                  decision_suc    = 0.99,
                  decision_fut    = 0,
                  borrow          = 'logOR',
                  test_statistic  = 'logOR')
stb_get_para(xx)

yy = stb_create_trial(xx, seed = 1)
stb_get_trial_data(yy)
stb_trial_plot(yy)

zz = stb_create_simustudy(xx,
                          n_rep = 1000,
                          seed = 1, n_core = 1)
stb_get_simu_key(zz)

octab = stb_tl_get_oc(x = xx,
                      ss_seq = seq(60,140,20),
                      n_rep = 1000,
                      seed = 1,
                      n_core = 1)
octab

### check power

stb_para(xx)=list(sample_size     = 100,
                  ratio_by_arm    = c(1, 2),
                  ratio_by_stage  = 1,
                  p_by_arm        = c(0.224, 0.13),
                  prior_by_arm    = list(prior),
                  n_post          = 10000,
                  test_direction  = 'less than',
                  decision_h0     = 0,
                  decision_suc    = 0.975,
                  decision_fut    = 0,
                  borrow          = 'logOR',
                  test_statistic  = 'logOR')
stb_get_para(xx)

zz = stb_create_simustudy(xx, n_rep = 1000, seed = 1, n_core=1)
stb_get_simu_key(zz)

octab = stb_tl_get_oc(x = xx,
                      ss_seq = seq(60,140,20),
                      n_rep = 1000,
                      seed = 1,
                      n_core = 1)
octab


### Borrow Risk Difference
### test H0: theta_d = 0 vs H1: theta_d < 0

h_prior = stb_tl_bayes_para_rmap(dtype = 'binary',
                                 borrow = 'diff',
                                 y.dif = -0.11,
                                 y.dif.se = 0.044,
                                 v = 0.1,
                                 m = 0,
                                 s = 0.1,
                                 weight_noninfo = 0.5,
                                 prior1_noninfo = 0,
                                 prior2_noninfo = 0.3,
                                 cores = 1)


xx = stb_create_design("bayes_mstage_bin")
stb_describe(xx)
stb_get_para(xx)

### check type 1 error

stb_para(xx) = list(
  sample_size     = 50,
  ratio_by_arm    = c(1,1),
  ratio_by_stage  = c(1,1,1),
  p_by_arm        = c(0.224, 0.224),
  prior_by_arm    = list(h_prior),
  n_post          = 10000,
  test_direction  = 'less than',
  decision_h0     = 0,
  decision_suc    = c(0.975, 0.975, 0.975),
  decision_fut    = c(0.4, 0.3, 0.2),
  borrow          = 'diff'
)

stb_get_para(xx)
yy = stb_create_trial(xx, seed = 10)
stb_trial_plot(yy)
zz = stb_create_simustudy(xx, n_rep = 1000, seed = 10, n_core=1)
stb_get_simu_key(zz)

octab = stb_tl_get_oc(x = xx,
                      ss_seq = seq(30,60,10),
                      n_rep = 1000,
                      seed = 1,
                      n_core = 1)
octab


### check power

stb_para(xx) = list(
  sample_size     = 50,
  ratio_by_arm    = c(1,1),
  ratio_by_stage  = c(1,1,1),
  p_by_arm        = c(0.224, 0.13),
  prior_by_arm    = list(h_prior),
  n_post          = 10000,
  test_direction  = 'less than',
  decision_h0     = 0,
  decision_suc    = c(0.975, 0.975, 0.975),
  decision_fut    = c(0.4, 0.3, 0.2),
  borrow          = 'diff',
  test_statistic  = 'diff'
)

stb_get_para(xx)
yy = stb_create_trial(xx, seed = 10)
stb_trial_plot(yy)
zz = stb_create_simustudy(xx, n_rep = 1000, seed = 10, n_core=1)
stb_get_simu_key(zz)

octab = stb_tl_get_oc(x = xx,
                      ss_seq = seq(30,60,10),
                      n_rep = 1000,
                      seed = 1,
                      n_core =1)
octab



### Borrow Historical Control

h_prior = stb_tl_bayes_para_rmap(dtype = 'binary',
                                 borrow = 'control',
                                 y = c(21, 14),
                                 N = c(100, 80),
                                 v = 0.1,
                                 m = 0,
                                 s = 0.1,
                                 weight_noninfo = 0.5,
                                 prior1_noninfo = 1,
                                 prior2_noninfo = 1,
                                 cores = 1)

xx = stb_create_design("bayes_mstage_bin")
stb_describe(xx)
stb_para(xx) = list(
  sample_size     = 50,
  ratio_by_arm    = c(1,2),
  ratio_by_stage  = c(1,1),
  p_by_arm        = c(0.224, 0.13),
  prior_by_arm    = list(h_prior, c(1, 1)), #Beta Prior
  n_post          = 10000,
  test_direction  = 'less than',
  decision_h0     = 0,
  decision_suc    = c(0.995, 0.995),
  decision_fut    = c(0.4, 0.3),
  borrow          = 'control',
  test_statistic  = 'logOR'
)

yy = stb_create_trial(xx, seed = 10)
stb_get_trial_data(yy)
stb_trial_plot(yy)

zz = stb_create_simustudy(xx, n_rep = 1000, seed = 10, n_core=1)
stb_get_simu_key(zz)




### No borrowing

xx = stb_create_design("bayes_mstage_bin")
stb_describe(xx)
stb_para(xx) = list(
  sample_size     = 50,
  ratio_by_arm    = c(1,2),
  ratio_by_stage  = c(1,1),
  p_by_arm        = c(0.224, 0.13),
  prior_by_arm    = list(c(1,1), c(1, 1)), #Beta Prior
  n_post          = 10000,
  test_direction  = 'less than',
  decision_h0     = 0,
  decision_suc    = c(0.995, 0.995),
  decision_fut    = c(0.4, 0.3),
  borrow          = 'control',
  test_statistic  = 'logOR'
)

yy = stb_create_trial(xx, seed = 10)
stb_get_trial_data(yy)
stb_trial_plot(yy)

zz = stb_create_simustudy(xx, n_rep = 1000, seed = 10, n_core=1)
stb_get_simu_key(zz)

## ---------------------------------------------------------------------
##
##    EXAMPLE : Bayesian Multi-Stage Design for Normal Endpoint
##
## ---------------------------------------------------------------------

### Borrow controls
### Test H0: theta_d = 4 vs H1: theta_d > 4

h_prior = stb_tl_bayes_para_pp(y.m = c(9.7, 10.5),
                               y.se = c(1.1, 1.3),
                               dtype = 'normal',
                               borrow = 'control',
                               prior1 = 0,
                               prior2 = 1,
                               power.param = 0.3,
                               cores = 1)

xx = stb_create_design("bayes_mstage_norm")
stb_describe(xx)
stb_get_para(xx)


### check power

stb_para(xx)=list(sample_size     = 30,
                  ratio_by_arm    = c(1, 2),
                  ratio_by_stage  = c(2, 1, 1),
                  prior_by_arm    = list(h_prior, c(0,1)), #Normal Prior
                  m_s_control     = c(10, 3),
                  m_s_treat       = c(15, 3),
                  n_post          = 10000,
                  test_direction  = 'greater than',
                  decision_h0     = 4,
                  decision_suc    = c(0.9, 0.9, 0.9),
                  decision_fut    = c(0.5, 0.4, 0.3),
                  borrow          = 'control')
stb_get_para(xx)

yy = stb_create_trial(xx, seed = 1)
stb_get_trial_data(yy)
stb_trial_plot(yy)
zz = stb_create_simustudy(xx, n_rep = 1000, seed = 1, n_core=1)
stb_get_simu_key(zz)

octab = stb_tl_get_oc(x = xx,
                      ss_seq = seq(30,50,10),
                      n_rep = 1000,
                      seed = 1,
                      n_core = 1)
octab

### check type 1 error
stb_para(xx)=list(sample_size     = 40,
                  ratio_by_arm    = c(1, 2),
                  ratio_by_stage  = c(2, 1, 1),
                  prior_by_arm    = list(h_prior, c(0,1)),
                  m_s_control     = c(10, 3),
                  m_s_treat       = c(14, 3),
                  n_post          = 10000,
                  test_direction  = 'greater than',
                  decision_h0     = 4,
                  decision_suc    = c(0.9, 0.9, 0.9),
                  decision_fut    = c(0.5, 0.4, 0.3),
                  borrow          = 'control')
stb_get_para(xx)

yy = stb_create_trial(xx, seed = 1)
stb_get_trial_data(yy)
stb_trial_plot(yy)
zz = stb_create_simustudy(xx, n_rep = 1000, seed = 1, n_core=1)
stb_get_simu_key(zz)



### borrow treatment difference
### Test H0: theta_d = 4 vs H1: theta_d > 4

h_prior = stb_tl_bayes_para_pp(y.dif = 3,
                               y.dif.se = 1,
                               dtype = 'normal',
                               borrow = 'diff',
                               prior1 = 0,
                               prior2 = 1,
                               power.param = 0.3,
                               cores = 1)


h_prior = stb_tl_bayes_para_rmap(y.dif = 3,
                                 y.dif.se = 1,
                                 dtype = 'normal',
                                 borrow = 'diff',
                                 v = 1,
                                 m = 0,
                                 s = 1,
                                 weight_noninfo = 0.5,
                                 prior1_noninfo = 0,
                                 prior2_noninfo = 1)

xx = stb_create_design("bayes_mstage_norm")
stb_describe(xx)
stb_get_para(xx)

### check type 1 error

stb_para(xx)=list(sample_size     = 30,
                  ratio_by_arm    = c(1, 1),
                  ratio_by_stage  = c(1, 1),
                  prior_by_arm    = list(h_prior),
                  m_s_control     = c(10, 3),
                  m_s_treat       = c(14, 3),
                  n_post          = 10000,
                  test_direction  = 'greater than',
                  decision_h0     = 4,
                  decision_suc    = c(0.95, 0.95),
                  decision_fut    = c(0.4, 0.3),
                  borrow          = 'diff')
stb_get_para(xx)

octab = stb_tl_get_oc(x = xx,
                      ss_seq = seq(60,120,20),
                      n_rep = 1000,
                      seed = 1,
                      n_core = 1)
octab

### check power
stb_para(xx)=list(sample_size     = 30,
                  ratio_by_arm    = c(1, 1),
                  ratio_by_stage  = c(1, 1),
                  prior_by_arm    = list(h_prior),
                  m_s_control     = c(10, 3),
                  m_s_treat       = c(15, 3),
                  n_post          = 10000,
                  test_direction  = 'greater than',
                  decision_h0     = 4,
                  decision_suc    = c(0.95, 0.95),
                  decision_fut    = c(0.4, 0.3),
                  borrow          = 'diff')
stb_get_para(xx)

yy = stb_create_trial(xx, seed = 1)
stb_trial_plot(yy)
stb_get_trial_data(yy)

octab = stb_tl_get_oc(x = xx,
                      ss_seq = seq(60,120,20),
                      n_rep = 1000,
                      seed = 1,
                      n_core = 1)
octab

